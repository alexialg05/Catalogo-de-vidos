#ifndef SISTEMASTREAMING_H
#define SISTEMASTREAMING_H

#include "Video.h"
#include "Pelicula.h"
#include "Serie.h"
#include <vector>

class SistemaStreaming {
private:
    vector<Video*> videos;

public:
    void agregarVideo(Video* video);
    void mostrarVideos() const;
    void mostrarPeliculas() const;
    void mostrarEpisodiosSerie(const string& nombreSerie) const;

    ~SistemaStreaming();
};

#endif // SISTEMASTREAMING_H
