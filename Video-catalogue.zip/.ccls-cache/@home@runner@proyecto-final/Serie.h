#ifndef SERIE_H
#define SERIE_H

#include "Video.h"
#include "Episodio.h"
#include <vector>

class Serie : public Video {
private:
    vector<Episodio> episodios;

public:
    Serie(int id, const string& nombre, int duracion, const string& genero);

    void agregarEpisodio(const Episodio& episodio);
    void mostrar() const override;
    void mostrarEpisodios() const;
};

#endif // SERIE_H
