#include "SistemaStreaming.h"
using namespace std;

void SistemaStreaming::agregarVideo(Video* video) {
    videos.push_back(video);
}

void SistemaStreaming::mostrarVideos() const {
    for (const auto& video : videos) {
        video->mostrar();
    }
}

void SistemaStreaming::mostrarPeliculas() const {
    for (const auto& video : videos) {
        if (dynamic_cast<Pelicula*>(video)) {
            video->mostrar();
        }
    }
}

void SistemaStreaming::mostrarEpisodiosSerie(const string& nombreSerie) const {
    for (const auto& video : videos) {
        Serie* serie = dynamic_cast<Serie*>(video);
        if (serie && serie->nombre == nombreSerie) {
            serie->mostrarEpisodios();
        }
    }
}

SistemaStreaming::~SistemaStreaming() {
    for (auto& video : videos) {
        delete video;
    }
}
