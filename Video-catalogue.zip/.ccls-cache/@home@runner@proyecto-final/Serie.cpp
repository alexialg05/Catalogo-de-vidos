#include "Serie.h"

Serie::Serie(int id, const string& nombre, int duracion, const string& genero)
    : Video(id, nombre, duracion, genero) {}

void Serie::agregarEpisodio(const Episodio& episodio) {
    episodios.push_back(episodio);
}

void Serie::mostrar() const {
    cout << "Serie(ID: " << id << ", Nombre: " << nombre << ", Duración: " << duracion 
         << " minutos, Género: " << genero << ", Calificación Promedio: " 
         << calificacionPromedio() << ", Episodios: " << episodios.size() << ")" << endl;
}

void Serie::mostrarEpisodios() const {
    cout << "Episodios de la serie " << nombre << ":" << endl;
    for (const auto& episodio : episodios) {
        episodio.mostrar();
    }
}
